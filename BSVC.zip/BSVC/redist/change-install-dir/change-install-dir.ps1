$x = Get-Content .\UI\bsvc.tk
Remove-Item .\UI\bsvc.tk
$x[0] = "set install_dir {$pwd}"
$x | Out-File -Encoding default .\UI\bsvc.tk